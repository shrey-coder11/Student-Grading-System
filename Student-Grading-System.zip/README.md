# Student Grading System

SQL Internship Project

**Intern ID:** CITS7424

## Project Description
A MySQL relational database for managing students, departments, courses, semesters, examinations, marks, grades, attendance, and academic performance.

## Features
- Student, course, department and instructor management
- Examination and marks management
- Automatic grade and grade-point calculation
- Attendance tracking
- Performance reports
- Views, stored procedures, functions and triggers
- Indexes, constraints and transactions

## Technologies
- MySQL
- SQL

## Internship Information
**Intern ID:** CITS7424
**Project:** Student Grading System
