CREATE DATABASE IF NOT EXISTS StudentGradingSystem;
USE StudentGradingSystem;
