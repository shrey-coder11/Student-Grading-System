USE StudentGradingSystem;
DELIMITER //
CREATE TRIGGER trg_validate_marks
BEFORE INSERT ON Marks FOR EACH ROW
BEGIN
 DECLARE max_allowed DECIMAL(6,2);
 SELECT MaxMarks INTO max_allowed FROM Examinations WHERE ExamID=NEW.ExamID;
 IF NEW.MarksObtained>max_allowed THEN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Marks exceed maximum marks';
 END IF;
END //
CREATE TRIGGER trg_calculate_grade
BEFORE INSERT ON Grades FOR EACH ROW
BEGIN
 SET NEW.Grade=CASE
 WHEN NEW.Percentage>=90 THEN 'A+'
 WHEN NEW.Percentage>=80 THEN 'A'
 WHEN NEW.Percentage>=70 THEN 'B+'
 WHEN NEW.Percentage>=60 THEN 'B'
 WHEN NEW.Percentage>=50 THEN 'C'
 WHEN NEW.Percentage>=40 THEN 'D'
 ELSE 'F' END;
 SET NEW.GradePoint=CalculateGradePoint(NEW.Percentage);
END //
DELIMITER ;
