USE StudentGradingSystem;
DELIMITER //
CREATE PROCEDURE GetStudentGrades(IN p_student_id INT)
BEGIN
 SELECT * FROM StudentCoursePerformance WHERE StudentID=p_student_id;
END //
CREATE PROCEDURE GetCourseStudents(IN p_course_id INT)
BEGIN
 SELECT s.StudentID,s.RollNumber,s.StudentName
 FROM Students s JOIN Enrollments e ON s.StudentID=e.StudentID
 WHERE e.CourseID=p_course_id;
END //
DELIMITER ;
