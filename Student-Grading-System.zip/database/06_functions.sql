USE StudentGradingSystem;
DELIMITER //
CREATE FUNCTION CalculateGradePoint(p_percentage DECIMAL(5,2))
RETURNS DECIMAL(3,2) DETERMINISTIC
BEGIN
 RETURN CASE
 WHEN p_percentage>=90 THEN 10.00
 WHEN p_percentage>=80 THEN 9.00
 WHEN p_percentage>=70 THEN 8.00
 WHEN p_percentage>=60 THEN 7.00
 WHEN p_percentage>=50 THEN 6.00
 WHEN p_percentage>=40 THEN 5.00
 ELSE 0.00 END;
END //
DELIMITER ;
