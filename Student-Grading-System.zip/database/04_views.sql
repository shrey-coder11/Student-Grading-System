USE StudentGradingSystem;

CREATE VIEW StudentCoursePerformance AS
SELECT s.StudentID,s.RollNumber,s.StudentName,c.CourseCode,c.CourseName,
sem.SemesterName,g.Percentage,g.Grade,g.GradePoint
FROM Grades g
JOIN Students s ON g.StudentID=s.StudentID
JOIN Courses c ON g.CourseID=c.CourseID
JOIN Semesters sem ON g.SemesterID=sem.SemesterID;

CREATE VIEW StudentAttendanceReport AS
SELECT s.StudentID,s.StudentName,c.CourseName,a.ClassesHeld,a.ClassesAttended,
ROUND((a.ClassesAttended/NULLIF(a.ClassesHeld,0))*100,2) AS AttendancePercentage
FROM Attendance a
JOIN Students s ON a.StudentID=s.StudentID
JOIN Courses c ON a.CourseID=c.CourseID;
