USE StudentGradingSystem;

INSERT INTO Departments VALUES
(1,'Computer Science and Engineering'),
(2,'Information Technology'),
(3,'Electronics and Communication Engineering');

INSERT INTO Students VALUES
(1,'CSE001','Aarav Sharma','M','2004-02-12','aarav@example.com','9000000001',1,2022),
(2,'CSE002','Ananya Rao','F','2004-06-18','ananya@example.com','9000000002',1,2022),
(3,'IT001','Rahul Kumar','M','2003-11-20','rahul@example.com','9000000003',2,2022),
(4,'IT002','Priya Singh','F','2004-03-14','priya@example.com','9000000004',2,2022),
(5,'ECE001','Kiran Reddy','M','2004-08-10','kiran@example.com','9000000005',3,2022);

INSERT INTO Instructors VALUES
(101,'Dr. Mehta','mehta@example.com',1),
(102,'Dr. Sharma','sharma@example.com',2),
(103,'Dr. Rao','rao@example.com',3);

INSERT INTO Courses VALUES
(201,'CS101','Database Management Systems',4,1),
(202,'CS102','Data Structures',4,1),
(203,'IT101','Web Technologies',3,2),
(204,'IT102','Operating Systems',4,2),
(205,'EC101','Computer Networks',4,3);

INSERT INTO Semesters VALUES
(301,'Semester 1','2025-26','2025-07-01','2025-12-15'),
(302,'Semester 2','2025-26','2026-01-05','2026-05-30');

INSERT INTO Enrollments VALUES
(401,1,201,301,'2025-07-05'),(402,1,202,301,'2025-07-05'),
(403,2,201,301,'2025-07-05'),(404,2,202,301,'2025-07-05'),
(405,3,203,301,'2025-07-05'),(406,3,204,301,'2025-07-05'),
(407,4,203,301,'2025-07-05'),(408,4,204,301,'2025-07-05'),
(409,5,205,301,'2025-07-05');

INSERT INTO Examinations VALUES
(501,201,301,'Midterm','2025-09-10',50),
(502,201,301,'Final','2025-12-05',100),
(503,202,301,'Midterm','2025-09-12',50),
(504,202,301,'Final','2025-12-07',100),
(505,203,301,'Final','2025-12-08',100),
(506,204,301,'Final','2025-12-09',100),
(507,205,301,'Final','2025-12-10',100);

INSERT INTO Marks VALUES
(601,1,501,43),(602,1,502,91),(603,1,503,45),(604,1,504,88),
(605,2,501,46),(606,2,502,94),(607,2,503,42),(608,2,504,90),
(609,3,505,84),(610,3,506,78),(611,4,505,91),(612,4,506,87),
(613,5,507,76);

INSERT INTO Attendance VALUES
(701,1,201,301,60,55),(702,1,202,301,62,58),
(703,2,201,301,60,57),(704,2,202,301,62,59),
(705,3,203,301,58,52),(706,3,204,301,60,54),
(707,4,203,301,58,56),(708,4,204,301,60,57),
(709,5,205,301,60,49);
