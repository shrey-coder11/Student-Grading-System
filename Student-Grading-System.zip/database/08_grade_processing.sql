USE StudentGradingSystem;
INSERT INTO Grades(StudentID,CourseID,SemesterID,Percentage)
SELECT m.StudentID,e.CourseID,e.SemesterID,
ROUND((SUM(m.MarksObtained)/SUM(e.MaxMarks))*100,2)
FROM Marks m JOIN Examinations e ON m.ExamID=e.ExamID
GROUP BY m.StudentID,e.CourseID,e.SemesterID
ON DUPLICATE KEY UPDATE Percentage=VALUES(Percentage);
