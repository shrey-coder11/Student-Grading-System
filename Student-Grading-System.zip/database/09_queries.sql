USE StudentGradingSystem;

SELECT * FROM Students;

SELECT s.StudentName,d.DepartmentName
FROM Students s JOIN Departments d ON s.DepartmentID=d.DepartmentID;

SELECT c.CourseName,s.StudentName
FROM Enrollments e
JOIN Students s ON e.StudentID=s.StudentID
JOIN Courses c ON e.CourseID=c.CourseID;

SELECT c.CourseName,ROUND(AVG(g.Percentage),2) AS AveragePercentage
FROM Grades g JOIN Courses c ON g.CourseID=c.CourseID
GROUP BY c.CourseID,c.CourseName;

SELECT s.StudentName,g.Percentage
FROM Grades g JOIN Students s ON g.StudentID=s.StudentID
ORDER BY g.Percentage DESC;

SELECT DISTINCT s.StudentName
FROM Grades g JOIN Students s ON g.StudentID=s.StudentID
WHERE g.Percentage>80;

SELECT s.StudentName,c.CourseName,g.Percentage,g.Grade
FROM Grades g JOIN Students s ON g.StudentID=s.StudentID
JOIN Courses c ON g.CourseID=c.CourseID
WHERE g.Grade='F';

SELECT d.DepartmentName,COUNT(s.StudentID) AS StudentCount
FROM Departments d LEFT JOIN Students s ON d.DepartmentID=s.DepartmentID
GROUP BY d.DepartmentID,d.DepartmentName;

SELECT * FROM StudentAttendanceReport WHERE AttendancePercentage<75;

SELECT s.StudentName,ROUND(AVG(g.GradePoint),2) AS GPA
FROM Grades g JOIN Students s ON g.StudentID=s.StudentID
GROUP BY s.StudentID,s.StudentName;

SELECT s.StudentName,ROUND(AVG(g.GradePoint),2) AS GPA
FROM Grades g JOIN Students s ON g.StudentID=s.StudentID
GROUP BY s.StudentID,s.StudentName
HAVING AVG(g.GradePoint)>=8;

SELECT CourseID,MAX(Percentage) AS HighestPercentage FROM Grades GROUP BY CourseID;

SELECT CourseID,MIN(Percentage) AS LowestPercentage FROM Grades GROUP BY CourseID;

CALL GetStudentGrades(1);

SELECT CalculateGradePoint(87.5) AS GradePoint;
