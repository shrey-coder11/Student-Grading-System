USE StudentGradingSystem;

CREATE TABLE Departments (
 DepartmentID INT PRIMARY KEY,
 DepartmentName VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Students (
 StudentID INT PRIMARY KEY,
 RollNumber VARCHAR(30) NOT NULL UNIQUE,
 StudentName VARCHAR(100) NOT NULL,
 Gender CHAR(1),
 DOB DATE,
 Email VARCHAR(120) UNIQUE,
 Phone VARCHAR(20),
 DepartmentID INT,
 AdmissionYear INT,
 FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID)
);

CREATE TABLE Instructors (
 InstructorID INT PRIMARY KEY,
 InstructorName VARCHAR(100) NOT NULL,
 Email VARCHAR(120) UNIQUE,
 DepartmentID INT,
 FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID)
);

CREATE TABLE Courses (
 CourseID INT PRIMARY KEY,
 CourseCode VARCHAR(20) NOT NULL UNIQUE,
 CourseName VARCHAR(100) NOT NULL,
 Credits INT NOT NULL CHECK (Credits > 0),
 DepartmentID INT,
 FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID)
);

CREATE TABLE Semesters (
 SemesterID INT PRIMARY KEY,
 SemesterName VARCHAR(50) NOT NULL,
 AcademicYear VARCHAR(20) NOT NULL,
 StartDate DATE,
 EndDate DATE
);

CREATE TABLE Enrollments (
 EnrollmentID INT PRIMARY KEY,
 StudentID INT NOT NULL,
 CourseID INT NOT NULL,
 SemesterID INT NOT NULL,
 EnrollmentDate DATE,
 FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
 FOREIGN KEY (CourseID) REFERENCES Courses(CourseID),
 FOREIGN KEY (SemesterID) REFERENCES Semesters(SemesterID),
 UNIQUE(StudentID, CourseID, SemesterID)
);

CREATE TABLE Examinations (
 ExamID INT PRIMARY KEY,
 CourseID INT NOT NULL,
 SemesterID INT NOT NULL,
 ExamType VARCHAR(30) NOT NULL,
 ExamDate DATE,
 MaxMarks DECIMAL(6,2) NOT NULL CHECK (MaxMarks > 0),
 FOREIGN KEY (CourseID) REFERENCES Courses(CourseID),
 FOREIGN KEY (SemesterID) REFERENCES Semesters(SemesterID)
);

CREATE TABLE Marks (
 MarkID INT PRIMARY KEY,
 StudentID INT NOT NULL,
 ExamID INT NOT NULL,
 MarksObtained DECIMAL(6,2) NOT NULL CHECK (MarksObtained >= 0),
 FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
 FOREIGN KEY (ExamID) REFERENCES Examinations(ExamID),
 UNIQUE(StudentID, ExamID)
);

CREATE TABLE Attendance (
 AttendanceID INT PRIMARY KEY,
 StudentID INT NOT NULL,
 CourseID INT NOT NULL,
 SemesterID INT NOT NULL,
 ClassesHeld INT DEFAULT 0,
 ClassesAttended INT DEFAULT 0,
 FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
 FOREIGN KEY (CourseID) REFERENCES Courses(CourseID),
 FOREIGN KEY (SemesterID) REFERENCES Semesters(SemesterID)
);

CREATE TABLE Grades (
 GradeID INT PRIMARY KEY AUTO_INCREMENT,
 StudentID INT NOT NULL,
 CourseID INT NOT NULL,
 SemesterID INT NOT NULL,
 Percentage DECIMAL(5,2),
 Grade VARCHAR(2),
 GradePoint DECIMAL(3,2),
 FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
 FOREIGN KEY (CourseID) REFERENCES Courses(CourseID),
 FOREIGN KEY (SemesterID) REFERENCES Semesters(SemesterID),
 UNIQUE(StudentID, CourseID, SemesterID)
);

CREATE INDEX idx_student_department ON Students(DepartmentID);
CREATE INDEX idx_enrollment_student ON Enrollments(StudentID);
CREATE INDEX idx_marks_student ON Marks(StudentID);
CREATE INDEX idx_exam_course ON Examinations(CourseID);
